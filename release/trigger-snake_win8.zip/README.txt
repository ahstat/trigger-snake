*****************
* Trigger snake *
*****************
Source: https://github.com/ahstat/trigger-snake/
Blog post: https://ahstat.github.io/Trigger-snake/

Trigger snake is a snake game with new features, making it fast, lively and challenging. Please note that there is no wall in the board. The aim is to reach a score of 3000; then to beat my hi-score of 16140.

Controls: After launching "trigger-snake.exe", you can type any key to begin a new game. Use directional keys to move the snake in the four directions and eat apples. Other special keys are:
- R -- restart a game in-game or after losing,
- D -- display density of snake's positions,
- E -- display density of snake's directions,
- W -- display density of snake's non-oriented directions,
- A -- display density of apples' positions,
- 1 -- cheat code: change apple's position,
- 2 -- cheat code: increase snake's length by one,
- 3 -- cheat code: win current game.

Have fun!
Feedback: ahstat@qq.com